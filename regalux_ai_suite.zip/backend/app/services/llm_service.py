import os
import json
import logging
from typing import Dict, Any, List, Optional
from app.core.config import settings

logger = logging.getLogger(__name__)

class LLMService:
    def __init__(self):
        self.api_key = settings.GROQ_API_KEY
        self.model = settings.GROQ_MODEL
        self.client = None
        if self.api_key:
            try:
                from groq import Groq
                self.client = Groq(api_key=self.api_key)
            except Exception as e:
                logger.warning(f"Failed to initialize Groq client: {e}")
                self.client = None

    def is_live_available(self) -> bool:
        return self.client is not None and bool(self.api_key) and not settings.DEMO_MODE

    async def generate_completion(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.7,
        json_mode: bool = False
    ) -> Dict[str, Any]:
        """
        Executes completion via Groq if available; otherwise returns None to trigger deterministic engine.
        """
        if not self.is_live_available():
            return {"live": False, "content": None}

        try:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
            response_format = {"type": "json_object"} if json_mode else None
            
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                response_format=response_format,
                max_tokens=2048
            )
            raw_text = completion.choices[0].message.content
            return {"live": True, "content": raw_text}
        except Exception as e:
            logger.error(f"Groq API call error: {e}")
            return {"live": False, "content": None, "error": str(e)}

llm_service = LLMService()
