import json
from typing import List, Dict, Any, Optional
from app.services.llm_service import llm_service
from app.services.vector_memory import vector_memory

class InterviewEngine:
    async def respond_to_researcher(
        self,
        persona: Dict[str, Any],
        message_history: List[Dict[str, Any]],
        new_message: str,
        stored_memories: List[Dict[str, Any]],
        product_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Simulates an authentic, consistent response from the persona to the researcher's question.
        Uses vector memory retrieval to ground response in persona's profile and established facts.
        """
        # Retrieve top relevant memories
        relevant_memories = vector_memory.retrieve_relevant(new_message, stored_memories, top_k=3)
        
        memories_summary = "\n".join([f"- {m.get('memory_text', '')}" for m in relevant_memories]) if relevant_memories else "None explicitly recalled yet."

        persona_name = persona.get("name", "Persona")
        occupation = persona.get("occupation", "Professional")
        segment = persona.get("segment", "General")
        budget = persona.get("budget", "Moderate")
        schedule = persona.get("schedule", "Standard work hours")
        diet = persona.get("dietary_prefs", "Standard")
        objections = ", ".join(persona.get("objections", []))
        motivations = ", ".join(persona.get("motivations", []))
        communication_style = persona.get("communication_style", "Direct and conversational")

        # Live LLM generation if available
        if llm_service.is_live_available():
            system_prompt = (
                f"You are {persona_name}, a {occupation} in {segment}.\n"
                f"Schedule: {schedule}\n"
                f"Budget: {budget}\n"
                f"Dietary preferences: {diet}\n"
                f"Motivations: {motivations}\n"
                f"Primary objections: {objections}\n"
                f"Communication style: {communication_style}\n"
                f"Relevant memories established earlier in research:\n{memories_summary}\n\n"
                f"Product being researched: {product_context.get('name')} ({product_context.get('description')}).\n"
                f"Respond directly to the researcher in your authentic voice. Never break character. "
                f"Never claim to be an AI. Acknowledge your specific constraints honestly. "
                f"Return JSON with 'response' (your reply) and 'internal_reasoning' (1 sentence)."
            )
            
            # Format chat history
            history_text = ""
            for msg in message_history[-6:]:
                role = "Researcher" if msg.get("sender") == "researcher" else persona_name
                history_text += f"{role}: {msg.get('content')}\n"
            
            user_prompt = f"{history_text}Researcher: {new_message}\n{persona_name}:"
            
            res = await llm_service.generate_completion(system_prompt, user_prompt, json_mode=True)
            if res.get("live") and res.get("content"):
                try:
                    data = json.loads(res["content"])
                    return {
                        "content": data.get("response", ""),
                        "reasoning": data.get("internal_reasoning", f"Reflects my perspective as {occupation}."),
                        "retrieved_memories": relevant_memories
                    }
                except Exception:
                    pass

        # High-fidelity deterministic conversational engine
        q_lower = new_message.lower()
        reply = ""
        reasoning = ""

        if any(w in q_lower for w in ["fee", "₹99", "price", "cost", "charge", "expensive"]):
            if "budget" in segment.lower() or "Associate" in occupation:
                reply = (
                    f"Honestly, ₹99 per order is a major deterrent for me. On my ₹4,500 monthly delivery budget, "
                    f"that fee represents nearly 40% of an ordinary ₹200 lunch. Unless there's a free delivery coupon or "
                    f"group ordering discount, I would stick to my current habit of splitting orders with colleagues."
                )
                reasoning = f"Budget constraints make high per-order delivery fees an immediate conversion hurdle."
            elif "consultant" in occupation.lower() or "convenience" in segment.lower() or "investor" in occupation.lower():
                reply = (
                    f"To be frank, ₹99 doesn't bother me at all if the delivery is truly guaranteed in 30 minutes. "
                    f"My billable hours and schedule don't allow room for delayed meals. I'd gladly pay ₹99—or better yet, "
                    f"a ₹499 monthly VIP pass with unlimited priority dispatch."
                )
                reasoning = f"Valuing time efficiency over marginal cost aligns with high-earning consultant profile."
            else:
                reply = (
                    f"₹99 feels steep if I'm just ordering a quick lunch for myself. However, if I'm ordering for a late meeting "
                    f"or family dinner above ₹600, ₹99 is palatable. A subscription model that waives this fee would make me consider it."
                )
                reasoning = f"Balanced trade-off between ticket size and delivery convenience."

        elif any(w in q_lower for w in ["30-minute", "30 min", "fast", "speed", "quick", "time", "delay"]):
            reply = (
                f"The 30-minute guarantee is what caught my eye. In my role as a {occupation}, my lunch breaks are rarely "
                f"longer than 45 minutes between sprint syncs. If an app promises 30 minutes and actually delivers in 28, "
                f"it earns my loyalty. But if it arrives in 50 minutes with excuses, I un-install."
            )
            reasoning = f"Strict time boundaries and meeting windows govern meal ordering decisions."

        elif any(w in q_lower for w in ["health", "diet", "clean", "salad", "macro", "calorie", "organic", "oil"]):
            if "health" in segment.lower() or "nutrition" in occupation.lower() or "vegetarian" in segment.lower():
                reply = (
                    f"I've been burned by apps that label greasy paneer or sugary dressings as 'healthy'. If SwiftBite "
                    f"partners with verified nutrition kitchens with transparent protein, carb, and fat breakdowns, "
                    f"it would solve a huge headache for my {diet} routine."
                )
                reasoning = f"Demands authentic nutritional transparency rather than superficial marketing."
            else:
                reply = (
                    f"Having balanced, light meal options during working afternoons is definitely appealing. "
                    f"Nobody wants a heavy carb coma at 2:30 PM before an executive presentation."
                )
                reasoning = f"Acknowledges afternoon productivity impact of heavy meals."

        elif any(w in q_lower for w in ["track", "map", "gps", "rider", "driver", "call"]):
            reply = (
                f"Live map tracking is non-negotiable for me. I don't want delivery executives calling three times while "
                f"I'm on a client presentation asking for building landmarks. If the app shows real-time GPS and accurate "
                f"gate arrival, it prevents seamless disruption."
            )
            reasoning = f"Focuses on uninterrupted workflow and minimal friction during work hours."

        elif any(w in q_lower for w in ["subscript", "plan", "monthly", "pass", "vip"]):
            reply = (
                f"A subscription plan makes total sense if the math works out. If I order 8 to 10 times a month and the "
                f"subscription is ₹199 to ₹299 with zero delivery charges and priority kitchen routing, I would subscribe on day one."
            )
            reasoning = f"Calculates subscription ROI based on recurring weekly order volume."

        else:
            reply = (
                f"From my perspective as a {occupation}, I look for consistency and reliability above all. "
                f"Between my {schedule} and food habits ({diet}), SwiftBite's proposal is compelling if the execution "
                f"matches the promise without unexpected surge pricing."
            )
            reasoning = f"Grounded response based on daily professional routine and personal dietary habits."

        return {
            "content": reply,
            "reasoning": reasoning,
            "retrieved_memories": relevant_memories
        }

interview_engine = InterviewEngine()
