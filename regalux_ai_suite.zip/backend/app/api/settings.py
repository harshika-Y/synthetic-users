from fastapi import APIRouter, Depends
from app.core.config import settings
from app.schemas.schemas import SettingsOut, SettingsUpdate
from app.services.llm_service import llm_service
from app.api.deps import get_current_user
from app.models.models import User

router = APIRouter(prefix="/settings", tags=["Settings"])

@router.get("", response_model=SettingsOut)
def get_settings(current_user: User = Depends(get_current_user)):
    return {
        "groq_api_key_configured": bool(settings.GROQ_API_KEY),
        "groq_model": settings.GROQ_MODEL,
        "demo_mode": settings.DEMO_MODE,
        "database_url": "MySQL (Production Engine)" if "mysql" in settings.DATABASE_URL else "SQLite (Local Auto-Fallback)"
    }

@router.post("", response_model=SettingsOut)
def update_settings(update_data: SettingsUpdate, current_user: User = Depends(get_current_user)):
    if update_data.groq_api_key is not None:
        settings.GROQ_API_KEY = update_data.groq_api_key
        # Re-initialize Groq client if key provided
        if settings.GROQ_API_KEY:
            try:
                from groq import Groq
                llm_service.client = Groq(api_key=settings.GROQ_API_KEY)
                llm_service.api_key = settings.GROQ_API_KEY
            except Exception:
                pass
        else:
            llm_service.client = None
            llm_service.api_key = ""

    if update_data.groq_model is not None:
        settings.GROQ_MODEL = update_data.groq_model
        llm_service.model = update_data.groq_model

    if update_data.demo_mode is not None:
        settings.DEMO_MODE = update_data.demo_mode

    return {
        "groq_api_key_configured": bool(settings.GROQ_API_KEY),
        "groq_model": settings.GROQ_MODEL,
        "demo_mode": settings.DEMO_MODE,
        "database_url": "MySQL (Production Engine)" if "mysql" in settings.DATABASE_URL else "SQLite (Local Auto-Fallback)"
    }
