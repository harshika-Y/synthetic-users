import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Lock, Mail, ArrowRight, ShieldCheck, 
  FlaskConical, X, CheckCircle2, AlertCircle, LogOut 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const ResearcherModal = ({ isOpen, onClose }) => {
  const { user, login, logout } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('researcher@regalux.ai');
  const [password, setPassword] = useState('RoyalSecret2026!');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleLogin = async (e) => {
    if (e) e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
      setSuccess(true);
      setTimeout(() => {
        onClose();
        navigate('/dashboard');
      }, 400);
    } catch (err) {
      setError(err.message || 'Authentication failed. Please verify researcher credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = async () => {
    setEmail('researcher@regalux.ai');
    setPassword('RoyalSecret2026!');
    setError('');
    setLoading(true);
    try {
      await login('researcher@regalux.ai', 'RoyalSecret2026!');
      setSuccess(true);
      setTimeout(() => {
        onClose();
        navigate('/dashboard');
      }, 400);
    } catch (err) {
      setError(err.message || 'Quick login failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleDirectContinue = () => {
    onClose();
    navigate('/dashboard');
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div 
        className="w-full max-w-md rounded-2xl border p-7 relative overflow-hidden shadow-2xl"
        style={{
          backgroundColor: '#0B0D12',
          borderColor: 'rgba(214, 182, 111, 0.4)',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.95), 0 0 35px rgba(214, 182, 111, 0.15)',
          color: '#F6F1E7'
        }}
      >
        {/* Glow corner ambient accent */}
        <div 
          className="absolute -top-24 -right-24 w-48 h-48 rounded-full pointer-events-none blur-3xl opacity-20"
          style={{ backgroundColor: '#D6B66F' }}
        />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#D6B66F]/70 hover:text-[#D6B66F] p-1.5 rounded-full hover:bg-white/5 transition-colors cursor-pointer"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header / Brand */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D6B66F] to-[#8C6D2B] flex items-center justify-center text-[#080A0E] shadow-lg shadow-[#D6B66F]/20 shrink-0">
            <FlaskConical className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono tracking-widest text-[#D6B66F] uppercase font-bold px-2 py-0.5 rounded bg-[#D6B66F]/10 border border-[#D6B66F]/30">
                Regalux AI Suite
              </span>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live
              </span>
            </div>
            <h2 className="text-lg font-bold text-[#F6F1E7] mt-1 tracking-tight font-royal-title">
              Researcher Studio Sign In
            </h2>
            <p className="text-xs text-[#A8B0BC]">Authenticate to access Synthetic Personas & Intelligence</p>
          </div>
        </div>

        {/* Active Session Notification if already signed in */}
        {user && (
          <div className="mb-4 p-3 rounded-xl bg-[#0F131A] border border-[#D6B66F]/30 flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] text-[#A8B0BC] block uppercase tracking-wider">Active Session</span>
              <span className="text-emerald-400 font-semibold">{user.email || 'researcher@regalux.ai'}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDirectContinue}
                className="px-3 py-1 rounded-full bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#080A0E] font-bold text-[11px] hover:brightness-110 cursor-pointer shadow"
              >
                Enter Studio →
              </button>
              <button
                type="button"
                onClick={() => logout()}
                className="p-1 text-rose-400 hover:text-rose-300 transition-colors"
                title="Sign out this session"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-950/70 border border-rose-500/40 text-xs text-rose-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>Authenticated successfully! Redirecting to studio...</span>
          </div>
        )}

        {/* Sign In Form */}
        <form onSubmit={handleLogin} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-[#D6B66F] uppercase mb-1">
              Researcher Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#D6B66F] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#07090D] border border-[#D6B66F]/30 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="researcher@regalux.ai"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#D6B66F] uppercase mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#D6B66F] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#07090D] border border-[#D6B66F]/30 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="••••••••••••"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-full font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 mt-4 bg-gradient-to-r from-[#D6B66F] via-[#E5C378] to-[#B3934B] text-[#080A0E] hover:brightness-110"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In as Researcher & Enter Studio'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick 1-Click Access for Convenience */}
        <div className="mt-4 pt-4 border-t border-[#D6B66F]/20 flex flex-col gap-2">
          <button
            onClick={handleQuickDemoLogin}
            type="button"
            disabled={loading}
            className="w-full py-2 rounded-lg bg-[#123D32]/50 hover:bg-[#123D32]/80 border border-[#1B5E4B] text-[11px] font-semibold text-emerald-300 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D6B66F]" />
            <span>1-Click Lead Researcher Quick Access</span>
          </button>
          <div className="text-center text-[10px] text-[#A8B0BC]/70">
            Pre-configured: <span className="text-[#D6B66F]">researcher@regalux.ai</span> / <span className="text-[#D6B66F]">RoyalSecret2026!</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResearcherModal;
