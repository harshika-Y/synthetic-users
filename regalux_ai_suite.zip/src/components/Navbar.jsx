import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Sparkles } from 'lucide-react';
import CustomerModal from './CustomerModal';
import ResearcherModal from './ResearcherModal';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [researcherModalOpen, setResearcherModalOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleOpen = () => setResearcherModalOpen(true);
    window.addEventListener('open-researcher-modal', handleOpen);
    return () => window.removeEventListener('open-researcher-modal', handleOpen);
  }, []);

  const handleResearcherClick = () => {
    // Always open the Researcher Sign In modal when clicked
    setResearcherModalOpen(true);
  };

  return (
    <>
      {/* Main Royal Cafe Navbar */}
      <nav 
        className="navbar" 
        style={{ 
          position: 'relative', 
          top: 0, 
          padding: '16px 5%', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          backgroundColor: 'rgba(8, 10, 14, 0.9)',
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(214, 182, 111, 0.22)'
        }}
      >
        <div className="nav-brand">
          <Link to="/">
            <img src="/logo.png" alt="Kadappa Cafe" style={{ height: '85px', width: 'auto' }} />
          </Link>
        </div>

        <div className="nav-links flex items-center gap-6">
          <Link to="/" className="nav-link">HOME</Link>
          <Link to="/about" className="nav-link">ABOUT</Link>
          <Link to="/menu" className="nav-link">MENU</Link>
          <Link to="/book" className="nav-link">BOOK TABLE</Link>
          <Link to="/contact" className="nav-link">CONTACT</Link>

          {/* Customer Login Button */}
          <button
            onClick={() => setCustomerModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#D6B66F]/50 text-xs font-semibold text-[#D6B66F] hover:bg-[#D6B66F]/10 transition-all cursor-pointer"
          >
            <User className="w-3.5 h-3.5" />
            <span>Customer Sign In</span>
          </button>

          {/* Royal AI Researcher Portal Button (Always opens Researcher Login modal) */}
          <button
            onClick={handleResearcherClick}
            className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-[#D6B66F] via-[#E5C378] to-[#B3934B] text-[#080A0E] text-xs font-bold hover:brightness-110 transition-all shadow-md shadow-[#D6B66F]/20 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#080A0E]" />
            <span>AI Researcher Studio</span>
          </button>
        </div>
      </nav>

      {/* Customer Experience Modal */}
      <CustomerModal 
        isOpen={customerModalOpen} 
        onClose={() => setCustomerModalOpen(false)} 
      />

      {/* Researcher Authentication & Studio Entry Modal */}
      <ResearcherModal
        isOpen={researcherModalOpen}
        onClose={() => setResearcherModalOpen(false)}
      />
    </>
  );
};

export default Navbar;
