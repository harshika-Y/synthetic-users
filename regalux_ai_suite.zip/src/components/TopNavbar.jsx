import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Building2, FlaskConical, Plus, Sparkles, 
  Cpu, LogOut, ChevronDown, UserCircle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';

const TopNavbar = () => {
  const { user, logout, activeExperiment, setActiveExperiment, isLiveAI } = useAuth();
  const [experiments, setExperiments] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchExps = async () => {
      try {
        const data = await api.getExperiments();
        setExperiments(data);
        if (data.length > 0 && !activeExperiment) {
          setActiveExperiment(data[0]);
        }
      } catch (e) {
        console.error("Failed to load experiments for navbar", e);
      }
    };
    fetchExps();
  }, []);

  return (
    <header className="h-16 bg-[#0B0D10]/95 backdrop-blur-md border-b border-[#D6B66F]/15 px-6 flex items-center justify-between z-20 shrink-0">
      {/* Workspace & Experiment Selectors */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 text-xs text-[#A8B0BC]">
          <Building2 className="w-4 h-4 text-[#D6B66F]" />
          <span className="font-medium text-[#F6F1E7]">Regalux Obsidian Lab</span>
          <span className="text-[#A8B0BC]/40">/</span>
        </div>

        {/* Experiment Dropdown */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#111827] border border-[#D6B66F]/25 text-xs text-[#F6F1E7] hover:border-[#D6B66F]/50 transition-colors"
          >
            <FlaskConical className="w-3.5 h-3.5 text-[#D6B66F]" />
            <span className="max-w-[200px] truncate font-medium">
              {activeExperiment ? activeExperiment.title : "Select Experiment"}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-[#A8B0BC]" />
          </button>

          {dropdownOpen && (
            <div className="absolute top-full left-0 mt-2 w-72 bg-[#111827] border border-[#D6B66F]/30 rounded-xl shadow-2xl py-2 z-50">
              <div className="px-3 py-1.5 text-[10px] uppercase font-semibold text-[#A8B0BC] border-b border-[#D6B66F]/10">
                Switch Active Experiment
              </div>
              <div className="max-h-60 overflow-y-auto">
                {experiments.map((exp) => (
                  <button
                    key={exp.id}
                    onClick={() => {
                      setActiveExperiment(exp);
                      setDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-[#123D32]/40 transition-colors ${
                      activeExperiment?.id === exp.id ? 'text-[#D6B66F] font-semibold bg-[#123D32]/20' : 'text-[#F6F1E7]'
                    }`}
                  >
                    <span className="truncate">{exp.title}</span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded capitalize ${
                      exp.status === 'completed' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-400'
                    }`}>
                      {exp.status}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Action Controls & User Pill */}
      <div className="flex items-center gap-4">
        {/* Live Engine Indicator */}
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#111827] border border-[#D6B66F]/20 text-[11px]">
          <Cpu className={`w-3.5 h-3.5 ${isLiveAI ? 'text-emerald-400' : 'text-amber-400'}`} />
          <span className="text-[#A8B0BC]">
            {isLiveAI ? 'Groq Live AI' : 'Deterministic Simulation'}
          </span>
          <span className={`w-1.5 h-1.5 rounded-full ${isLiveAI ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        </div>

        {/* New Experiment Button */}
        <button
          onClick={() => navigate('/experiments/new')}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-semibold hover:brightness-110 transition-all shadow-md shadow-[#D6B66F]/10 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Experiment</span>
        </button>

        {/* User Profile Dropdown */}
        <div className="relative">
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="flex items-center gap-2.5 p-1 rounded-full hover:ring-1 hover:ring-[#D6B66F]/30 transition-all"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#123D32] to-[#111827] border border-[#D6B66F]/40 flex items-center justify-center text-[#D6B66F] font-bold text-xs">
              {user?.full_name ? user.full_name.charAt(0) : 'R'}
            </div>
          </button>

          {userMenuOpen && (
            <div className="absolute right-0 top-full mt-2 w-56 bg-[#111827] border border-[#D6B66F]/30 rounded-xl shadow-2xl py-2 z-50">
              <div className="px-4 py-2 border-b border-[#D6B66F]/10">
                <p className="text-xs font-semibold text-[#F6F1E7] truncate">{user?.full_name || "Principal Researcher"}</p>
                <p className="text-[10px] text-[#A8B0BC] truncate">{user?.email || "researcher@regalux.ai"}</p>
                <span className="inline-block mt-1 text-[9px] px-2 py-0.5 rounded-full bg-[#123D32] text-[#34D399] uppercase tracking-wider font-medium">
                  {user?.role || "Chief Research Scientist"}
                </span>
              </div>
              <button
                onClick={() => {
                  setUserMenuOpen(false);
                  logout();
                  navigate('/login');
                }}
                className="w-full text-left px-4 py-2 text-xs text-rose-400 hover:bg-rose-950/30 flex items-center gap-2 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default TopNavbar;
