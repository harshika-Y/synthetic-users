import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Users, FlaskConical, ClipboardList, 
  MessagesSquare, Sparkles, Gauge, Layers, FileText, 
  Sliders, UtensilsCrossed, ShieldAlert, ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const NAV_ITEMS = [
  { name: 'Overview', path: '/dashboard', icon: LayoutDashboard },
  { name: 'Persona Studio', path: '/personas', icon: Users },
  { name: 'Experiments', path: '/experiments', icon: FlaskConical },
  { name: 'Survey Lab', path: '/surveys', icon: ClipboardList },
  { name: 'Interview Room', path: '/interviews', icon: MessagesSquare },
  { name: 'Insights', path: '/insights', icon: Sparkles },
  { name: 'Adoption Score', path: '/adoption', icon: Gauge },
  { name: 'Scenario Library', path: '/scenarios', icon: Layers },
  { name: 'Research Reports', path: '/reports', icon: FileText },
  { name: 'Settings', path: '/settings', icon: Sliders },
];

const Sidebar = () => {
  const { activeExperiment, isLiveAI } = useAuth();
  const navigate = useNavigate();

  return (
    <aside className="w-64 bg-[#0B0D10] border-r border-[#D6B66F]/15 flex flex-col h-screen select-none shrink-0 z-30">
      {/* Brand Header */}
      <div className="p-6 border-b border-[#D6B66F]/15 flex items-center gap-3">
        <div className="w-9 h-9 rounded-md bg-gradient-to-br from-[#D6B66F] to-[#123D32] flex items-center justify-center shadow-lg shadow-[#D6B66F]/10 border border-[#D6B66F]/40">
          <span className="font-royal-title text-base font-bold text-[#0B0D10]">R</span>
        </div>
        <div>
          <h1 className="font-royal-title text-lg tracking-widest text-[#F6F1E7] font-bold leading-tight">
            REGALUX<span className="text-[#D6B66F] ml-1">AI</span>
          </h1>
          <p className="text-[9px] uppercase tracking-widest text-[#A8B0BC]">Research Intelligence</p>
        </div>
      </div>

      {/* Nav Menu */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] uppercase tracking-wider text-[#A8B0BC]/70 font-semibold">
          Platform Suite
        </div>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => `
                flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all duration-200
                ${isActive 
                  ? 'bg-gradient-to-r from-[#123D32]/60 to-[#111827] text-[#D6B66F] border-l-2 border-[#D6B66F] shadow-sm shadow-[#123D32]/20 font-semibold' 
                  : 'text-[#A8B0BC] hover:text-[#F6F1E7] hover:bg-[#111827]/70 hover:translate-x-0.5'
                }
              `}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate">{item.name}</span>
            </NavLink>
          );
        })}

        <div className="pt-4 pb-2 px-3 text-[10px] uppercase tracking-wider text-[#A8B0BC]/70 font-semibold">
          Subject Under Study
        </div>
        <NavLink
          to="/cafe"
          className={({ isActive }) => `
            flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all duration-200
            ${isActive 
              ? 'bg-[#123D32]/40 text-[#D6B66F] border-l-2 border-[#D6B66F]' 
              : 'text-[#A8B0BC] hover:text-[#F6F1E7] hover:bg-[#111827]/70'
            }
          `}
        >
          <div className="flex items-center gap-2.5 truncate">
            <UtensilsCrossed className="w-4 h-4 shrink-0 text-[#D6B66F]" />
            <span className="truncate">Kadappa Cafe / SwiftBite</span>
          </div>
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#123D32] text-[#34D399] uppercase tracking-wider">Demo</span>
        </NavLink>
      </nav>

      {/* Active Experiment Capsule */}
      <div className="p-3 m-3 rounded-lg bg-[#111827]/90 border border-[#D6B66F]/20">
        <div className="flex items-center justify-between text-[10px] text-[#A8B0BC] mb-1">
          <span className="uppercase tracking-wider font-semibold">Active Study</span>
          <span className={`w-2 h-2 rounded-full ${isLiveAI ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        </div>
        <p className="text-xs font-semibold text-[#F6F1E7] truncate">
          {activeExperiment?.title || "SwiftBite Corporate Study"}
        </p>
        <p className="text-[10px] text-[#D6B66F] mt-0.5">
          {isLiveAI ? "Live Groq AI Engine" : "High-Fidelity Simulation"}
        </p>
      </div>

      {/* Mandatory Synthetic Disclaimer */}
      <div className="px-4 py-2 border-t border-[#D6B66F]/10 text-[9px] text-[#A8B0BC]/70 flex items-center gap-1.5 leading-tight">
        <ShieldAlert className="w-3.5 h-3.5 text-amber-500/80 shrink-0" />
        <span>Synthetic Research Simulator. Not verified human survey.</span>
      </div>
    </aside>
  );
};

export default Sidebar;
