import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Layers, CheckCircle, Play, Sparkles, AlertCircle, 
  Clock, ShieldCheck, ArrowRight, RefreshCw, Cpu
} from 'lucide-react';
import { api } from '../services/api';

const ScenarioLibrary = () => {
  const navigate = useNavigate();
  const [scenarios, setScenarios] = useState([]);
  const [evaluationResults, setEvaluationResults] = useState(null);
  const [evaluating, setEvaluating] = useState(false);
  const [instantiating, setInstantiating] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadScenarios = async () => {
      try {
        setLoading(true);
        const data = await api.getScenarios();
        setScenarios(data);
      } catch (err) {
        console.error("Failed to load scenarios:", err);
      } finally {
        setLoading(false);
      }
    };
    loadScenarios();
  }, []);

  const handleInstantiate = async (key) => {
    setInstantiating(key);
    try {
      const res = await api.instantiateScenario(key);
      alert(`Scenario cloned! Created study: "${res.title}". Redirecting to Experiment Builder...`);
      navigate('/experiments');
    } catch (err) {
      alert("Instantiation failed: " + err.message);
    } finally {
      setInstantiating(null);
    }
  };

  const handleRunEvaluations = async () => {
    setEvaluating(true);
    try {
      const results = await api.runCrossDomainTests();
      setEvaluationResults(results);
    } catch (err) {
      alert("Cross-domain evaluation failed: " + err.message);
    } finally {
      setEvaluating(false);
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#D6B66F]/15 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-5 h-5 text-[#D6B66F]" />
            <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">
              Scenario Library & Cross-Domain Validation
            </h1>
          </div>
          <p className="text-xs text-[#A8B0BC]">
            Preloaded product domains for multi-segment validation. Instantiate into active studies or run automated schema tests.
          </p>
        </div>

        <button
          onClick={handleRunEvaluations}
          disabled={evaluating}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-bold hover:brightness-110 transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#D6B66F]/15 disabled:opacity-50"
        >
          <Play className="w-3.5 h-3.5 fill-[#0B0D10]" />
          <span>{evaluating ? "Executing Cross-Domain Suite..." : "Run Cross-Domain Validation Suite"}</span>
        </button>
      </div>

      {/* Automated Evaluation Results Table (If executed) */}
      {evaluationResults && (
        <div className="p-6 rounded-2xl royal-card border border-emerald-500/30 space-y-4">
          <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3">
            <div className="flex items-center gap-2 text-emerald-400">
              <CheckCircle className="w-5 h-5" />
              <h3 className="font-royal-title text-base font-bold text-[#F6F1E7]">
                Cross-Domain Validation Suite Passed (5 of 5 Domains Verified)
              </h3>
            </div>
            <span className="text-xs font-mono text-emerald-300">
              {evaluationResults.total_checks_passed} Checks Passed / 0 Failures
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            {evaluationResults.results?.map(r => (
              <div key={r.scenario_key} className="p-3 rounded-xl bg-[#0B0D10] border border-emerald-500/20 space-y-1">
                <span className="text-[10px] uppercase font-bold text-emerald-400">STATUS: PASS</span>
                <p className="font-bold text-[#F6F1E7] truncate">{r.scenario_title.split('—')[0]}</p>
                <p className="text-[10px] text-[#A8B0BC]">{r.category}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5 Preloaded Scenarios Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {scenarios.map((sc) => (
          <div key={sc.id} className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#123D32] text-[#34D399] border border-[#1B5E4B]">
                  {sc.category}
                </span>
                <span className="text-[10px] text-[#D6B66F] font-mono">{sc.key}</span>
              </div>

              <h3 className="font-royal-title text-base font-bold text-[#F6F1E7] mb-1">
                {sc.title}
              </h3>

              <p className="text-xs text-[#A8B0BC] leading-relaxed mb-4">
                {sc.description}
              </p>

              <div className="space-y-2 text-xs border-t border-[#D6B66F]/10 pt-3">
                <div className="flex items-center justify-between text-[#A8B0BC]">
                  <span>Target Demographic:</span>
                  <strong className="text-[#F6F1E7] truncate max-w-[150px]">{sc.target_audience}</strong>
                </div>
                <div className="flex items-center justify-between text-[#A8B0BC]">
                  <span>Tested Hypotheses:</span>
                  <strong className="text-[#D6B66F]">{sc.features?.length || 4} Core Pillars</strong>
                </div>
                <div className="flex items-center justify-between text-[#A8B0BC]">
                  <span>Validation Rules:</span>
                  <strong className="text-emerald-400">{sc.validation_checks?.length || 2} Checks</strong>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleInstantiate(sc.key)}
              disabled={instantiating === sc.key}
              className="w-full py-2.5 rounded-lg bg-[#111827] border border-[#D6B66F]/30 hover:border-[#D6B66F] text-xs font-semibold text-[#F6F1E7] hover:text-[#D6B66F] flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-40"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D6B66F]" />
              <span>{instantiating === sc.key ? "Cloning Scenario..." : "Instantiate into Active Study"}</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScenarioLibrary;
