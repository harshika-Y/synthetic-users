import React, { useState, useEffect } from 'react';
import { 
  Sparkles, CheckCircle2, AlertTriangle, ArrowRight, 
  Quote, ShieldAlert, RefreshCw, Layers, TrendingUp, Filter
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

const CATEGORIES = ["All Categories", "Pricing & Unit Economics", "Delivery SLA & Speed", "Health & Nutrition", "Subscription & Monetization"];

const InsightsDashboard = () => {
  const { activeExperiment } = useAuth();
  const [insightRun, setInsightRun] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);

  const loadInsights = async () => {
    if (!activeExperiment) return;
    try {
      setLoading(true);
      const res = await api.getInsights(activeExperiment.id);
      setInsightRun(res);
    } catch (e) {
      console.warn("Failed to load insights:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInsights();
  }, [activeExperiment]);

  const handleReRunInsights = async () => {
    if (!activeExperiment) return;
    setRunning(true);
    try {
      const res = await api.runInsights(activeExperiment.id);
      setInsightRun(res);
    } catch (e) {
      alert("Failed to run insights: " + e.message);
    } finally {
      setRunning(false);
    }
  };

  const filteredThemes = insightRun?.themes?.filter(t => {
    if (selectedCategory === "All Categories") return true;
    return t.category === selectedCategory;
  }) || [];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#D6B66F]/15 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-[#D6B66F]" />
            <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">
              Insight Intelligence Agent
            </h1>
          </div>
          <p className="text-xs text-[#A8B0BC]">
            Extracted strategic findings, theme clusters, and verified participant evidence grounded in stored survey and interview data.
          </p>
        </div>

        <button
          onClick={handleReRunInsights}
          disabled={running}
          className="px-4 py-2 rounded-lg bg-[#123D32] hover:bg-[#123D32]/80 border border-[#1B5E4B] text-xs font-semibold text-[#34D399] flex items-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-40"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${running ? 'animate-spin' : ''}`} />
          <span>{running ? "Analyzing Evidence..." : "Re-Run Insight Agent"}</span>
        </button>
      </div>

      {/* Synthesis Summary Card */}
      {insightRun && (
        <div className="p-6 rounded-2xl royal-card border border-[#D6B66F]/25 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#D6B66F]">
              Executive Research Synthesis
            </span>
            <span className="text-xs font-semibold text-emerald-400">
              {insightRun.adoption_rate}% Simulated Adoption Potential
            </span>
          </div>
          <p className="text-sm text-[#F6F1E7] leading-relaxed font-serif-royal">
            {insightRun.summary}
          </p>
        </div>
      )}

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-[#123D32] border border-[#D6B66F] text-[#D6B66F] font-semibold'
                : 'bg-[#111827] border border-[#D6B66F]/15 text-[#A8B0BC] hover:text-[#F6F1E7]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Themes List */}
      <div className="space-y-6">
        {filteredThemes.map((theme) => {
          const isNegative = theme.sentiment === 'negative';
          const isPositive = theme.sentiment === 'positive';

          return (
            <div
              key={theme.id}
              className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 space-y-5 transition-all hover:border-[#D6B66F]/40"
            >
              {/* Theme Top Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#D6B66F]/15 pb-4">
                <div>
                  <div className="flex items-center gap-3 mb-1.5">
                    <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded border ${
                      isNegative
                        ? 'bg-rose-950/60 border-rose-500/40 text-rose-300'
                        : isPositive
                        ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                        : 'bg-[#111827] border-[#D6B66F]/30 text-[#D6B66F]'
                    }`}>
                      {theme.category}
                    </span>
                    <span className="text-xs text-[#A8B0BC]">
                      Confidence: <strong className="text-[#F6F1E7] font-mono">{Math.round(theme.confidence * 100)}%</strong>
                    </span>
                  </div>
                  <h2 className="font-royal-title text-lg font-bold text-[#F6F1E7]">{theme.title}</h2>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] text-[#A8B0BC]">
                    Supported by <strong>{theme.participant_count} personas</strong>
                  </span>
                </div>
              </div>

              {/* Theme Narrative */}
              <p className="text-xs text-[#F6F1E7]/90 leading-relaxed">
                {theme.summary}
              </p>

              {/* Supporting Quotes Box */}
              {theme.supporting_quotes?.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-[#D6B66F] block">
                    Verified Synthetic Quotations
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {theme.supporting_quotes.map((q, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-[#0B0D10] border-l-2 border-[#D6B66F] border-r border-t border-b border-[#D6B66F]/10">
                        <Quote className="w-3.5 h-3.5 text-[#D6B66F]/60 mb-1" />
                        <p className="text-xs text-[#F6F1E7]/90 italic leading-relaxed">
                          "{q.quote}"
                        </p>
                        <p className="text-[10px] text-[#D6B66F] mt-2 font-mono">
                          — {q.persona_name} <span className="text-[#A8B0BC]">({q.persona_segment})</span>
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Product Implication Box */}
              {theme.product_implication && (
                <div className="p-4 rounded-xl bg-gradient-to-r from-[#123D32]/40 to-[#111827] border border-[#1B5E4B]">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-[#34D399] block mb-1">
                    Strategic Product Implication
                  </span>
                  <p className="text-xs text-[#F6F1E7] leading-relaxed">
                    {theme.product_implication}
                  </p>
                </div>
              )}

              {/* Counterexamples & Limitations */}
              {(theme.counterexamples || theme.limitations) && (
                <div className="pt-2 text-[11px] text-[#A8B0BC] space-y-1">
                  {theme.counterexamples && (
                    <p><strong>Divergence / Counterexample:</strong> {theme.counterexamples}</p>
                  )}
                  {theme.limitations && (
                    <p className="text-amber-300/80"><strong>Limitations:</strong> {theme.limitations}</p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default InsightsDashboard;
