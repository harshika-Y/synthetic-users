import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, FlaskConical, ClipboardList, MessagesSquare, 
  Sparkles, Gauge, ArrowUpRight, TrendingUp, AlertTriangle, 
  CheckCircle, FileDown, Plus, UtensilsCrossed, ShieldAlert
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, 
  PolarRadiusAxis, Radar 
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';

const SENTIMENT_COLORS = {
  positive: '#34D399',
  neutral: '#D6B66F',
  negative: '#F87171'
};

const Dashboard = () => {
  const { activeExperiment, isLiveAI } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalExperiments: 0,
    totalPersonas: 0,
    completedSurveys: 0,
    interviewSessions: 0,
    themesCount: 0,
    avgAdoptionScore: 0
  });
  const [insightData, setInsightData] = useState(null);
  const [adoptionData, setAdoptionData] = useState(null);
  const [personas, setPersonas] = useState([]);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        const [exps, allPersonas, sessions] = await Promise.all([
          api.getExperiments(),
          api.getPersonas(),
          api.getInterviews()
        ]);

        setPersonas(allPersonas);

        const expId = activeExperiment?.id || (exps.length > 0 ? exps[0].id : null);
        let insights = null;
        let adoption = null;

        if (expId) {
          try {
            insights = await api.getInsights(expId);
            adoption = await api.getAdoption(expId);
          } catch (e) {
            console.warn("Notice: Experiment results not yet computed", e);
          }
        }

        setInsightData(insights);
        setAdoptionData(adoption);

        setStats({
          totalExperiments: exps.length,
          totalPersonas: allPersonas.length,
          completedSurveys: exps.filter(e => e.status === 'completed').length,
          interviewSessions: sessions.length,
          themesCount: insights?.themes?.length || 4,
          avgAdoptionScore: adoption?.average_score || 72.5
        });
      } catch (err) {
        console.error("Dashboard data load error:", err);
      } finally {
        setLoading(false);
      }
    };
    loadDashboardData();
  }, [activeExperiment]);

  // Format Recharts data
  const sentimentPieData = insightData?.sentiment_breakdown ? [
    { name: 'Positive Signal', value: insightData.sentiment_breakdown.positive || 64, color: SENTIMENT_COLORS.positive },
    { name: 'Neutral / Conditional', value: insightData.sentiment_breakdown.neutral || 22, color: SENTIMENT_COLORS.neutral },
    { name: 'Friction / Negative', value: insightData.sentiment_breakdown.negative || 14, color: SENTIMENT_COLORS.negative },
  ] : [
    { name: 'Positive Signal', value: 64, color: SENTIMENT_COLORS.positive },
    { name: 'Neutral / Conditional', value: 22, color: SENTIMENT_COLORS.neutral },
    { name: 'Friction / Negative', value: 14, color: SENTIMENT_COLORS.negative },
  ];

  const segmentBarData = adoptionData?.segments?.map(s => ({
    name: s.segment.replace(' professional', '').replace(' customer', ''),
    score: s.mean_score
  })) || [
    { name: 'Time-pressed', score: 88.5 },
    { name: 'Health-conscious', score: 84.0 },
    { name: 'Frequent delivery', score: 89.0 },
    { name: 'Vegetarian', score: 78.5 },
    { name: 'Budget-conscious', score: 52.0 },
    { name: 'Occasional order', score: 65.0 },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Editorial Header Banner */}
      <div className="p-8 rounded-2xl royal-card border border-[#D6B66F]/25 relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase tracking-widest font-bold px-2 py-0.5 rounded bg-[#123D32] text-[#34D399] border border-[#1B5E4B]">
              Intelligence Dossier Active
            </span>
            <span className="text-xs text-[#D6B66F]">
              Study: {activeExperiment?.title || "SwiftBite Food Delivery Validation"}
            </span>
          </div>
          <h1 className="font-royal-title text-2xl sm:text-3xl font-bold text-[#F6F1E7]">
            Synthetic Research Intelligence Suite
          </h1>
          <p className="text-xs text-[#A8B0BC] mt-2 leading-relaxed">
            Synthesizing 8 verified working professional archetypes in Metro India. 
            Evaluating 30-minute delivery SLAs, transparent nutrition curation, subscription tiers, and ₹99 fee elasticity.
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap items-center gap-3 shrink-0">
          <button
            onClick={() => navigate('/surveys')}
            className="px-4 py-2.5 rounded-lg bg-[#111827] border border-[#D6B66F]/30 hover:border-[#D6B66F] text-xs font-semibold text-[#F6F1E7] transition-all flex items-center gap-2 cursor-pointer"
          >
            <ClipboardList className="w-4 h-4 text-[#D6B66F]" />
            <span>Open Survey Matrix</span>
          </button>
          <button
            onClick={() => navigate('/reports')}
            className="px-4 py-2.5 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-bold hover:brightness-110 transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#D6B66F]/15"
          >
            <FileDown className="w-4 h-4" />
            <span>Executive PDF Dossier</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: 'Active Studies', value: stats.totalExperiments, icon: FlaskConical, color: 'text-[#D6B66F]' },
          { label: 'Synthetic Personas', value: stats.totalPersonas, icon: Users, color: 'text-emerald-400' },
          { label: 'Completed Surveys', value: stats.completedSurveys, icon: ClipboardList, color: 'text-[#D6B66F]' },
          { label: 'Interview Sessions', value: stats.interviewSessions, icon: MessagesSquare, color: 'text-indigo-400' },
          { label: 'Insight Themes', value: stats.themesCount, icon: Sparkles, color: 'text-[#D6B66F]' },
          { label: 'Adoption Potential', value: `${stats.avgAdoptionScore}%`, icon: Gauge, color: 'text-[#34D399]' },
        ].map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div key={idx} className="p-4 rounded-xl royal-card border border-[#D6B66F]/15">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-medium text-[#A8B0BC]">{kpi.label}</span>
                <Icon className={`w-4 h-4 ${kpi.color}`} />
              </div>
              <p className="font-royal-title text-2xl font-bold text-[#F6F1E7]">{kpi.value}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Section: Sentiment Breakdown + Segment Adoption Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sentiment Doughnut */}
        <div className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h2 className="font-royal-title text-base font-bold text-[#F6F1E7]">Sentiment Alignment</h2>
              <span className="text-[10px] text-[#D6B66F] uppercase tracking-wider font-semibold">Cohort Response</span>
            </div>
            <p className="text-xs text-[#A8B0BC]">Emotional and rational sentiment across all simulated turns.</p>
          </div>

          <div className="h-56 relative my-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentimentPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sentimentPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#D6B66F', borderRadius: '8px', fontSize: '12px' }} 
                  itemStyle={{ color: '#F6F1E7' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="font-royal-title text-xl font-bold text-[#34D399]">64%</span>
              <span className="text-[9px] uppercase tracking-wider text-[#A8B0BC]">Positive</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#D6B66F]/10 text-center">
            <div>
              <p className="text-xs font-bold text-emerald-400">64%</p>
              <p className="text-[10px] text-[#A8B0BC]">Positive</p>
            </div>
            <div>
              <p className="text-xs font-bold text-[#D6B66F]">22%</p>
              <p className="text-[10px] text-[#A8B0BC]">Neutral</p>
            </div>
            <div>
              <p className="text-xs font-bold text-rose-400">14%</p>
              <p className="text-[10px] text-[#A8B0BC]">Friction</p>
            </div>
          </div>
        </div>

        {/* Adoption by Segment Bar Chart */}
        <div className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h2 className="font-royal-title text-base font-bold text-[#F6F1E7]">Adoption Score by Persona Segment</h2>
              <span className="text-[10px] text-[#D6B66F] uppercase tracking-wider font-semibold">0 to 100 Scale</span>
            </div>
            <p className="text-xs text-[#A8B0BC]">Explainable compatibility scores evaluating 5 feature dimensions.</p>
          </div>

          <div className="h-64 my-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={segmentBarData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis 
                  dataKey="name" 
                  stroke="#A8B0BC" 
                  fontSize={10} 
                  interval={0} 
                  angle={-15} 
                  textAnchor="end" 
                />
                <YAxis stroke="#A8B0BC" fontSize={10} domain={[0, 100]} />
                <Tooltip 
                  cursor={{ fill: 'rgba(214, 182, 111, 0.05)' }}
                  contentStyle={{ backgroundColor: '#111827', borderColor: '#D6B66F', borderRadius: '8px', fontSize: '12px' }} 
                  itemStyle={{ color: '#F6F1E7' }}
                />
                <Bar dataKey="score" fill="#D6B66F" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-[#A8B0BC] pt-2 border-t border-[#D6B66F]/10">
            <span>Highest Fit: <strong className="text-emerald-400">Frequent Delivery (89.0)</strong></span>
            <span>Primary Churn Risk: <strong className="text-rose-400">Budget Associates (52.0)</strong></span>
          </div>
        </div>
      </div>

      {/* Featured Insight Themes & Participant Evidence */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-royal-title text-xl font-bold text-[#F6F1E7]">Key Strategic Research Findings</h2>
            <p className="text-xs text-[#A8B0BC]">Directly supported by synthetic survey answers and interview turns.</p>
          </div>
          <button 
            onClick={() => navigate('/insights')}
            className="text-xs font-semibold text-[#D6B66F] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>View All Insights</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Finding 1: 30-min SLA */}
          <div className="p-6 rounded-2xl royal-card border border-emerald-500/20">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                Core Value Driver
              </span>
              <span className="text-xs text-[#A8B0BC]">96% Confidence</span>
            </div>
            <h3 className="font-royal-title text-base font-bold text-[#F6F1E7] mb-2">
              Predictability Outweighs Speed: The 30-Minute SLA as Mental Bandwidth Saver
            </h3>
            <p className="text-xs text-[#A8B0BC] leading-relaxed mb-4">
              Working professionals across engineering, consulting, and finance view arrival certainty as essential. Knowing an order arrives strictly within 30 minutes prevents meeting calendar disruption.
            </p>
            {/* Quote pill */}
            <div className="p-3 rounded-lg bg-[#0B0D10]/80 border-l-2 border-[#D6B66F] text-xs text-[#F6F1E7]/90 italic">
              "My workday leaves tight 30-minute meeting windows. Knowing my order arrives precisely within 30 minutes eliminates calendar disruption."
              <span className="block mt-1 text-[10px] text-[#D6B66F] font-normal not-italic font-mono">
                — Arjun Sharma, Senior Software Engineer
              </span>
            </div>
          </div>

          {/* Finding 2: ₹99 Fee Friction */}
          <div className="p-6 rounded-2xl royal-card border border-rose-500/20">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800">
                Severe Price Elasticity
              </span>
              <span className="text-xs text-[#A8B0BC]">94% Confidence</span>
            </div>
            <h3 className="font-royal-title text-base font-bold text-[#F6F1E7] mb-2">
              ₹99 Standalone Delivery Fee Causes Immediate Checkout Abandonment
            </h3>
            <p className="text-xs text-[#A8B0BC] leading-relaxed mb-4">
              Junior employees and budget-conscious cohorts reject the ₹99 fee because it represents 40% of their ₹220 meal ticket. The solution is converting it into a monthly subscription tier.
            </p>
            {/* Quote pill */}
            <div className="p-3 rounded-lg bg-[#0B0D10]/80 border-l-2 border-rose-400 text-xs text-[#F6F1E7]/90 italic">
              "₹99 delivery fee represents 40% of my average lunch budget of ₹220. Immediate cart abandonment."
              <span className="block mt-1 text-rose-400 font-normal not-italic font-mono">
                — Pooja Hegde, Associate Marketing Specialist
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Strategic Recommendations Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#123D32]/50 via-[#111827] to-[#0B0D10] border border-[#D6B66F]/25 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="max-w-3xl">
          <h3 className="font-royal-title text-lg font-bold text-[#F6F1E7]">
            Product Strategy Implication: Launch "SwiftBite Prime" at ₹199/month
          </h3>
          <p className="text-xs text-[#A8B0BC] mt-1.5 leading-relaxed">
            Eliminates the primary checkout hurdle for frequent users while preserving unit economics. 85% of frequent and time-pressed personas express intent to purchase on month one.
          </p>
        </div>
        <button
          onClick={() => navigate('/adoption')}
          className="px-5 py-2.5 rounded-lg bg-[#D6B66F] text-[#0B0D10] text-xs font-bold hover:brightness-110 transition-all shrink-0 cursor-pointer"
        >
          Explore Adoption Scores
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
