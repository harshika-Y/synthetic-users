import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Mail, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('researcher@regalux.ai');
  const [password, setPassword] = useState('RoyalSecret2026!');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleAutofillDemo = () => {
    setEmail('researcher@regalux.ai');
    setPassword('RoyalSecret2026!');
  };

  return (
    <div className="min-h-screen bg-[#0B0D10] text-[#F6F1E7] flex items-center justify-center p-6 relative">
      <div className="absolute inset-0 bg-radial-gradient from-[#123D32]/20 to-[#0B0D10] pointer-events-none" />

      <div className="w-full max-w-md p-8 rounded-2xl bg-[#111827]/90 border border-[#D6B66F]/25 shadow-2xl relative z-10">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D6B66F] to-[#123D32] flex items-center justify-center mx-auto mb-3 shadow-lg shadow-[#D6B66F]/20 border border-[#D6B66F]/40">
            <span className="font-royal-title text-xl font-bold text-[#0B0D10]">R</span>
          </div>
          <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">Researcher Access</h1>
          <p className="text-xs text-[#A8B0BC] mt-1">Sign in to your Regalux Intelligence workspace</p>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-rose-950/50 border border-rose-500/40 text-xs text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#A8B0BC] mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#D6B66F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="researcher@regalux.ai"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#A8B0BC] mb-1.5">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#D6B66F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="••••••••••••"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-bold hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D6B66F]/10 disabled:opacity-50"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In to Workspace'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-[#D6B66F]/15 flex flex-col gap-3">
          <button
            onClick={handleAutofillDemo}
            type="button"
            className="w-full py-2 rounded-lg bg-[#123D32]/40 hover:bg-[#123D32]/70 border border-[#1B5E4B] text-[11px] font-semibold text-[#34D399] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Autofill Seeded Demo Credentials</span>
          </button>

          <p className="text-center text-xs text-[#A8B0BC]">
            Need a new research profile?{' '}
            <Link to="/register" className="text-[#D6B66F] hover:underline font-medium">
              Create Account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
