import React, { useState, useEffect } from 'react';
import { 
  Sliders, Key, Cpu, Database, ShieldCheck, 
  CheckCircle2, Sparkles, AlertCircle, Save
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

const MODELS = [
  { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B Versatile (Recommended)' },
  { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B Instant (Ultra-Fast)' },
  { id: 'mixtral-8x7b-32768', name: 'Mixtral 8x7B (High Context)' }
];

const SettingsPage = () => {
  const { isLiveAI } = useAuth();
  const [apiKey, setApiKey] = useState("");
  const [model, setModel] = useState("llama-3.3-70b-versatile");
  const [demoMode, setDemoMode] = useState(false);
  const [dbStatus, setDbStatus] = useState("SQLite (Local Auto-Fallback)");
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const data = await api.getSettings();
        setModel(data.groq_model || 'llama-3.3-70b-versatile');
        setDemoMode(data.demo_mode);
        setDbStatus(data.database_url);
      } catch (err) {
        console.error("Failed to load settings:", err);
      }
    };
    loadSettings();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSaveSuccess(false);
    try {
      await api.updateSettings({
        groq_api_key: apiKey ? apiKey : undefined,
        groq_model: model,
        demo_mode: demoMode
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      alert("Failed to update settings: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="border-b border-[#D6B66F]/15 pb-6">
        <div className="flex items-center gap-2 mb-1">
          <Sliders className="w-5 h-5 text-[#D6B66F]" />
          <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">
            System Configuration & AI Provider Settings
          </h1>
        </div>
        <p className="text-xs text-[#A8B0BC]">
          Configure LLM inference credentials, model selection, demo mode behavior, and database engines.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>System configuration updated successfully. Provider connections reloaded.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Groq API Key Card */}
        <div className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 space-y-4">
          <div className="flex items-center justify-between border-b border-[#D6B66F]/10 pb-3">
            <div className="flex items-center gap-2">
              <Key className="w-4 h-4 text-[#D6B66F]" />
              <h3 className="font-royal-title text-sm font-bold text-[#F6F1E7]">Groq API Credentials</h3>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
              isLiveAI ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'
            }`}>
              {isLiveAI ? 'Live Groq Connected' : 'Demo Simulation Mode'}
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider mb-2">
              Groq API Key (Optional)
            </label>
            <input
              type="password"
              placeholder="gsk_••••••••••••••••••••••••••••••••••••••••••••"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="w-full px-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] focus:outline-none focus:border-[#D6B66F]"
            />
            <p className="text-[11px] text-[#A8B0BC] mt-1.5 leading-relaxed">
              Never exposed to the client. If left blank, REGALUX AI automatically runs on its built-in high-fidelity deterministic simulation engine.
            </p>
          </div>
        </div>

        {/* Model Selection */}
        <div className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#D6B66F]/10 pb-3">
            <Cpu className="w-4 h-4 text-[#D6B66F]" />
            <h3 className="font-royal-title text-sm font-bold text-[#F6F1E7]">Groq Model Architecture</h3>
          </div>

          <div className="space-y-2">
            {MODELS.map(m => (
              <label
                key={m.id}
                className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                  model === m.id 
                    ? 'bg-[#123D32]/40 border-[#D6B66F] text-[#F6F1E7]' 
                    : 'bg-[#0B0D10] border-[#D6B66F]/10 text-[#A8B0BC] hover:border-[#D6B66F]/30'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="groq_model"
                    value={m.id}
                    checked={model === m.id}
                    onChange={(e) => setModel(e.target.value)}
                    className="accent-[#D6B66F]"
                  />
                  <span className="text-xs font-medium">{m.name}</span>
                </div>
                <span className="text-[10px] font-mono text-[#D6B66F]">{m.id}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Infrastructure & Database */}
        <div className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 space-y-4">
          <div className="flex items-center gap-2 border-b border-[#D6B66F]/10 pb-3">
            <Database className="w-4 h-4 text-[#D6B66F]" />
            <h3 className="font-royal-title text-sm font-bold text-[#F6F1E7]">Database & Memory Infrastructure</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/15">
              <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Primary Relational Store</span>
              <p className="font-semibold text-emerald-400 mt-1">{dbStatus}</p>
              <p className="text-[10px] text-[#A8B0BC] mt-0.5">Supports MySQL in production & SQLite local fallback.</p>
            </div>
            <div className="p-3.5 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/15">
              <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Persona Vector Memory</span>
              <p className="font-semibold text-[#D6B66F] mt-1">Local Cosine Vector Store</p>
              <p className="text-[10px] text-[#A8B0BC] mt-0.5">Zero cloud telemetry. Sub-millisecond semantic recall.</p>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-bold hover:brightness-110 transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-[#D6B66F]/15 disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? "Saving Configuration..." : "Save Settings"}</span>
        </button>
      </form>
    </div>
  );
};

export default SettingsPage;
