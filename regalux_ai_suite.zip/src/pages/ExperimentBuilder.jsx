import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FlaskConical, CheckCircle2, ArrowRight, ArrowLeft, 
  Sparkles, Layers, Users, Play, Clock, ShieldCheck, Plus, Trash2
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

const STEPS = [
  "1. Product Definition",
  "2. Target Personas",
  "3. Research Methods",
  "4. Questions Config",
  "5. Review & Launch"
];

const ExperimentBuilder = () => {
  const navigate = useNavigate();
  const { setActiveExperiment } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);

  // Form State
  const [products, setProducts] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState("");
  const [title, setTitle] = useState("SwiftBite: Q4 Urban Professionals Adoption Study");
  const [objective, setObjective] = useState("Evaluate 30-min SLA value proposition, healthy meal demand, and ₹99 fee tolerance.");
  const [primaryQuestion, setPrimaryQuestion] = useState("Would busy working professionals adopt SwiftBite for regular weekday office meals?");
  const [method, setMethod] = useState("both"); // survey, interview, both

  // Personas
  const [personas, setPersonas] = useState([]);
  const [selectedPersonaIds, setSelectedPersonaIds] = useState([]);

  // Questions
  const [questions, setQuestions] = useState([
    {
      question_text: "How likely are you to use a 30-minute food delivery service during your workday?",
      question_type: "rating_scale",
      options: ["1 - Very Unlikely", "2", "3 - Neutral", "4", "5 - Essential"],
      required: true
    },
    {
      question_text: "Is a ₹99 delivery fee acceptable for guaranteed 30-minute delivery?",
      question_type: "single_choice",
      options: ["Completely Acceptable", "Acceptable if SLA is guaranteed", "Neutral / Conditional", "Unacceptable / Too High"],
      required: true
    },
    {
      question_text: "How important is a dedicated, dietician-verified healthy food section?",
      question_type: "rating_scale",
      options: ["1", "2", "3", "4", "5"],
      required: true
    },
    {
      question_text: "Would you subscribe to a monthly pass (₹199/mo) offering unlimited free 30-min deliveries?",
      question_type: "single_choice",
      options: ["Very Likely", "Moderately Likely", "Unlikely"],
      required: true
    },
    {
      question_text: "What is your single biggest concern or barrier regarding adopting SwiftBite?",
      question_type: "open_ended",
      options: [],
      required: true
    }
  ]);

  // Execution State
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prods, pers] = await Promise.all([
          api.getProducts(),
          api.getPersonas()
        ]);
        setProducts(prods);
        if (prods.length > 0) setSelectedProductId(prods[0].id);
        setPersonas(pers);
        setSelectedPersonaIds(pers.map(p => p.id));
      } catch (err) {
        console.error("Failed to load initial experiment builder data", err);
      }
    };
    fetchData();
  }, []);

  const handleTogglePersona = (id) => {
    if (selectedPersonaIds.includes(id)) {
      setSelectedPersonaIds(selectedPersonaIds.filter(pid => pid !== id));
    } else {
      setSelectedPersonaIds([...selectedPersonaIds, id]);
    }
  };

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      {
        question_text: "New research question...",
        question_type: "single_choice",
        options: ["Option A", "Option B", "Option C"],
        required: true
      }
    ]);
  };

  const handleRemoveQuestion = (idx) => {
    setQuestions(questions.filter((_, i) => i !== idx));
  };

  const handleLaunchExperiment = async () => {
    setIsRunning(true);
    setProgress(15);
    setStatusMessage("Creating experiment architecture in database...");

    try {
      // 1. Create experiment record
      const exp = await api.createExperiment({
        product_id: selectedProductId,
        title,
        objective,
        primary_question: primaryQuestion,
        method,
        selected_persona_ids: selectedPersonaIds,
        questions_config: questions.map((q, idx) => ({ ...q, order_idx: idx + 1 }))
      });

      setProgress(40);
      setStatusMessage("Dispatching parallel survey simulations across 8 personas...");

      // 2. Run simulation pipeline
      await api.runExperiment(exp.id);

      setProgress(75);
      setStatusMessage("Extracting insight clusters, calculating adoption scores, and validating consistency...");

      setTimeout(() => {
        setProgress(100);
        setStatusMessage("Experiment completed successfully!");
        setActiveExperiment(exp);
        setTimeout(() => {
          navigate('/surveys');
        }, 1200);
      }, 1000);

    } catch (err) {
      alert("Error running experiment: " + err.message);
      setIsRunning(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Title */}
      <div className="border-b border-[#D6B66F]/15 pb-6">
        <div className="flex items-center gap-2 mb-1">
          <FlaskConical className="w-5 h-5 text-[#D6B66F]" />
          <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">Experiment Builder</h1>
        </div>
        <p className="text-xs text-[#A8B0BC]">
          Design a structured synthetic research study with custom hypothesis testing, persona cohorts, and survey matrix parameters.
        </p>
      </div>

      {/* Stepper Wizard Indicator */}
      <div className="grid grid-cols-5 gap-2">
        {STEPS.map((step, idx) => {
          const isActive = idx === currentStep;
          const isDone = idx < currentStep;
          return (
            <div
              key={idx}
              className={`p-2.5 rounded-lg border text-center transition-all ${
                isActive 
                  ? 'bg-[#123D32]/60 border-[#D6B66F] text-[#D6B66F] font-bold text-xs' 
                  : isDone 
                  ? 'bg-[#111827] border-emerald-500/40 text-emerald-400 text-xs' 
                  : 'bg-[#0B0D10] border-[#D6B66F]/10 text-[#A8B0BC]/60 text-xs'
              }`}
            >
              <span className="truncate block">{step}</span>
            </div>
          );
        })}
      </div>

      {/* Stepper Content Body */}
      <div className="p-8 rounded-2xl royal-card border border-[#D6B66F]/20">
        {/* Step 0: Product Definition */}
        {currentStep === 0 && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider mb-2">
                Select Researched Product
              </label>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] focus:outline-none focus:border-[#D6B66F]"
              >
                {products.map(p => (
                  <option key={p.id} value={p.id} className="bg-[#111827]">{p.name} ({p.category})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider mb-2">
                Experiment Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] focus:outline-none focus:border-[#D6B66F]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider mb-2">
                Core Research Objective
              </label>
              <textarea
                rows="2"
                value={objective}
                onChange={(e) => setObjective(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] focus:outline-none focus:border-[#D6B66F]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider mb-2">
                Primary Research Question
              </label>
              <input
                type="text"
                value={primaryQuestion}
                onChange={(e) => setPrimaryQuestion(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] focus:outline-none focus:border-[#D6B66F]"
              />
            </div>
          </div>
        )}

        {/* Step 1: Target Personas */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider">
                Select Personas to Participate ({selectedPersonaIds.length} Selected)
              </span>
              <button
                type="button"
                onClick={() => setSelectedPersonaIds(personas.map(p => p.id))}
                className="text-xs text-[#D6B66F] hover:underline cursor-pointer"
              >
                Select All
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
              {personas.map((p) => {
                const isSelected = selectedPersonaIds.includes(p.id);
                return (
                  <div
                    key={p.id}
                    onClick={() => handleTogglePersona(p.id)}
                    className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      isSelected 
                        ? 'bg-[#123D32]/40 border-[#D6B66F] text-[#F6F1E7]' 
                        : 'bg-[#0B0D10] border-[#D6B66F]/10 text-[#A8B0BC] hover:border-[#D6B66F]/30'
                    }`}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <img src={p.avatar} alt={p.name} className="w-8 h-8 rounded-lg object-cover" />
                      <div className="truncate">
                        <p className="text-xs font-bold truncate">{p.name}</p>
                        <p className="text-[10px] text-[#A8B0BC] truncate">{p.segment}</p>
                      </div>
                    </div>
                    <span className={`w-4 h-4 rounded flex items-center justify-center border text-[10px] ${
                      isSelected ? 'bg-[#D6B66F] border-[#D6B66F] text-[#0B0D10] font-bold' : 'border-[#A8B0BC]/40'
                    }`}>
                      {isSelected ? '✓' : ''}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2: Research Methods */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <label className="block text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider mb-2">
              Choose Research Modality
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { key: 'survey', title: 'Survey Mode Only', desc: 'Parallel quantitative matrix across all personas with individual reasoning.' },
                { key: 'interview', title: 'Interview Mode Only', desc: 'Deep multi-turn 1-on-1 qualitative discovery with episodic memory recall.' },
                { key: 'both', title: 'Comprehensive (Both)', desc: 'Full quantitative survey matrix + stateful 1-on-1 interview deep dives.' },
              ].map(m => (
                <div
                  key={m.key}
                  onClick={() => setMethod(m.key)}
                  className={`p-5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                    method === m.key 
                      ? 'bg-[#123D32]/50 border-[#D6B66F] text-[#F6F1E7] shadow-lg shadow-[#D6B66F]/10' 
                      : 'bg-[#0B0D10] border-[#D6B66F]/10 text-[#A8B0BC] hover:border-[#D6B66F]/30'
                  }`}
                >
                  <div>
                    <h3 className="font-royal-title text-sm font-bold text-[#F6F1E7] mb-1">{m.title}</h3>
                    <p className="text-xs text-[#A8B0BC] leading-relaxed">{m.desc}</p>
                  </div>
                  <span className={`mt-4 text-[10px] uppercase font-bold tracking-wider ${method === m.key ? 'text-[#D6B66F]' : 'text-transparent'}`}>
                    Active Selection
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Questions Config */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#A8B0BC] uppercase tracking-wider">
                Configure Survey Questions ({questions.length})
              </span>
              <button
                type="button"
                onClick={handleAddQuestion}
                className="px-3 py-1.5 rounded-lg bg-[#123D32] border border-[#1B5E4B] text-xs font-semibold text-[#34D399] flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Question</span>
              </button>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {questions.map((q, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/15 space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <span className="w-6 h-6 rounded-full bg-[#111827] border border-[#D6B66F]/30 flex items-center justify-center text-xs text-[#D6B66F] font-bold">
                      {idx + 1}
                    </span>
                    <input
                      type="text"
                      value={q.question_text}
                      onChange={(e) => {
                        const copy = [...questions];
                        copy[idx].question_text = e.target.value;
                        setQuestions(copy);
                      }}
                      className="flex-1 px-3 py-1.5 rounded-lg bg-[#111827] border border-[#D6B66F]/20 text-xs text-[#F6F1E7]"
                    />
                    <button
                      onClick={() => handleRemoveQuestion(idx)}
                      className="text-rose-400 hover:text-rose-300 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-[#A8B0BC]">Question Type:</span>
                    <select
                      value={q.question_type}
                      onChange={(e) => {
                        const copy = [...questions];
                        copy[idx].question_type = e.target.value;
                        setQuestions(copy);
                      }}
                      className="px-3 py-1 rounded bg-[#111827] border border-[#D6B66F]/20 text-xs text-[#F6F1E7]"
                    >
                      <option value="single_choice">Single Choice</option>
                      <option value="rating_scale">Rating Scale (1-5)</option>
                      <option value="likert">Likert Scale</option>
                      <option value="yes_no">Yes / No</option>
                      <option value="open_ended">Open Ended</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 4: Review & Launch */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <h3 className="font-royal-title text-base font-bold text-[#F6F1E7] border-b border-[#D6B66F]/15 pb-2">
              Review Experiment Specification
            </h3>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/10">
                <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Study Title</span>
                <p className="text-[#F6F1E7] font-semibold mt-1">{title}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/10">
                <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Method</span>
                <p className="text-[#D6B66F] font-semibold mt-1 capitalize">{method} Mode</p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/10">
                <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Cohort Size</span>
                <p className="text-[#F6F1E7] font-semibold mt-1">{selectedPersonaIds.length} Synthetic Personas</p>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/10">
                <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Questions Matrix</span>
                <p className="text-[#F6F1E7] font-semibold mt-1">{questions.length} Evaluated Dimensions</p>
              </div>
            </div>

            {/* Execution Progress Bar (when running) */}
            {isRunning && (
              <div className="p-6 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/40 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#D6B66F] animate-pulse">{statusMessage}</span>
                  <span className="font-mono text-[#F6F1E7] font-bold">{progress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-[#111827] overflow-hidden border border-[#D6B66F]/20">
                  <div 
                    className="h-full bg-gradient-to-r from-[#D6B66F] to-[#34D399] transition-all duration-500" 
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Wizard Navigation Footer */}
        <div className="mt-8 pt-6 border-t border-[#D6B66F]/15 flex items-center justify-between">
          <button
            type="button"
            disabled={currentStep === 0 || isRunning}
            onClick={() => setCurrentStep(currentStep - 1)}
            className="px-4 py-2 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs font-semibold text-[#A8B0BC] hover:text-[#F6F1E7] disabled:opacity-30 cursor-pointer flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>

          {currentStep < STEPS.length - 1 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(currentStep + 1)}
              className="px-5 py-2.5 rounded-lg bg-[#D6B66F] text-[#0B0D10] text-xs font-bold hover:brightness-110 cursor-pointer flex items-center gap-1.5 shadow-md shadow-[#D6B66F]/15"
            >
              <span>Continue</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              disabled={isRunning}
              onClick={handleLaunchExperiment}
              className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#34D399] text-[#0B0D10] text-xs font-bold hover:brightness-110 cursor-pointer flex items-center gap-2 shadow-xl shadow-[#34D399]/20 disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-[#0B0D10]" />
              <span>{isRunning ? "Executing Pipeline..." : "Launch Research Pipeline"}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExperimentBuilder;
