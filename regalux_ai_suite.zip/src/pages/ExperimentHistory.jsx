import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FlaskConical, Clock, CheckCircle2, ChevronRight, FileText, ArrowRight } from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

const ExperimentHistory = () => {
  const navigate = useNavigate();
  const { setActiveExperiment } = useAuth();
  const [experiments, setExperiments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const data = await api.getExperiments();
        setExperiments(data);
      } catch (e) {
        console.error("Failed to load history:", e);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const handleSelectAndNavigate = (exp) => {
    setActiveExperiment(exp);
    navigate('/dashboard');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="border-b border-[#D6B66F]/15 pb-6">
        <div className="flex items-center gap-2 mb-1">
          <Clock className="w-5 h-5 text-[#D6B66F]" />
          <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">
            Experiment Archive & Study History
          </h1>
        </div>
        <p className="text-xs text-[#A8B0BC]">
          Complete repository of past synthetic research simulations, hypotheses tested, and archived results.
        </p>
      </div>

      <div className="space-y-4">
        {experiments.map((exp) => (
          <div
            key={exp.id}
            className="p-6 rounded-2xl royal-card border border-[#D6B66F]/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-[#D6B66F]/40 transition-all"
          >
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-3">
                <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                  exp.status === 'completed'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : 'bg-amber-950 text-amber-400 border border-amber-800'
                }`}>
                  {exp.status}
                </span>
                <span className="text-[11px] text-[#A8B0BC]">
                  {new Date(exp.created_at).toLocaleDateString()}
                </span>
              </div>

              <h3 className="font-royal-title text-base font-bold text-[#F6F1E7]">
                {exp.title}
              </h3>
              <p className="text-xs text-[#A8B0BC] line-clamp-1">
                {exp.objective}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => handleSelectAndNavigate(exp)}
                className="px-4 py-2 rounded-lg bg-[#111827] border border-[#D6B66F]/30 hover:border-[#D6B66F] text-xs font-semibold text-[#D6B66F] flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>Select & Open Dashboard</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExperimentHistory;
