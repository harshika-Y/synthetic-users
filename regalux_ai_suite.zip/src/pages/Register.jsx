import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Mail, User, Shield, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Principal Researcher');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await register(email, password, fullName, role);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0D10] text-[#F6F1E7] flex items-center justify-center p-6 relative">
      <div className="w-full max-w-md p-8 rounded-2xl bg-[#111827]/90 border border-[#D6B66F]/25 shadow-2xl relative z-10">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D6B66F] to-[#123D32] flex items-center justify-center mx-auto mb-3 shadow-lg shadow-[#D6B66F]/20 border border-[#D6B66F]/40">
            <span className="font-royal-title text-xl font-bold text-[#0B0D10]">R</span>
          </div>
          <h1 className="font-royal-title text-2xl font-bold text-[#F6F1E7]">Register Profile</h1>
          <p className="text-xs text-[#A8B0BC] mt-1">Join the synthetic intelligence laboratory</p>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-rose-950/50 border border-rose-500/40 text-xs text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#A8B0BC] mb-1.5">Full Name</label>
            <div className="relative">
              <User className="w-4 h-4 text-[#D6B66F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="Dr. Alexander Wright"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#A8B0BC] mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#D6B66F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="alexander@regalux.ai"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#A8B0BC] mb-1.5">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#D6B66F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
                placeholder="••••••••••••"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#A8B0BC] mb-1.5">Research Role</label>
            <div className="relative">
              <Shield className="w-4 h-4 text-[#D6B66F] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-[#0B0D10] border border-[#D6B66F]/20 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F] transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-bold hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D6B66F]/10 disabled:opacity-50"
          >
            <span>{loading ? 'Creating...' : 'Register Workspace Account'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-[#A8B0BC]">
          Already have access?{' '}
          <Link to="/login" className="text-[#D6B66F] hover:underline font-medium">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
