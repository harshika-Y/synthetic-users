import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, ShieldCheck, Sparkles, Users, 
  MessageSquare, FileText, CheckCircle2, ChevronRight,
  TrendingUp, Compass, Cpu, Layers
} from 'lucide-react';
import ThreeBackground from '../components/ThreeBackground';

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0B0D10] text-[#F6F1E7] relative selection:bg-[#D6B66F]/20 selection:text-[#D6B66F]">
      {/* Three.js Interactive Particle Background */}
      <ThreeBackground />

      {/* Top Navigation */}
      <header className="relative z-10 max-w-7xl mx-auto px-6 h-20 flex items-center justify-between border-b border-[#D6B66F]/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-md bg-gradient-to-br from-[#D6B66F] to-[#123D32] flex items-center justify-center shadow-lg shadow-[#D6B66F]/15 border border-[#D6B66F]/40">
            <span className="font-royal-title text-base font-bold text-[#0B0D10]">R</span>
          </div>
          <div>
            <span className="font-royal-title text-lg tracking-widest text-[#F6F1E7] font-bold">
              REGALUX<span className="text-[#D6B66F] ml-1">AI</span>
            </span>
            <span className="hidden sm:inline-block text-[9px] uppercase tracking-widest text-[#A8B0BC] ml-2 pl-2 border-l border-[#D6B66F]/20">
              User Research Intelligence
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/login')}
            className="text-xs font-medium text-[#A8B0BC] hover:text-[#D6B66F] transition-colors px-3 py-1.5"
          >
            Researcher Sign In
          </button>
          <button 
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-xs font-semibold hover:brightness-110 transition-all shadow-md shadow-[#D6B66F]/15 cursor-pointer"
          >
            <span>Launch Studio</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 max-w-5xl mx-auto px-6 pt-24 pb-20 text-center">
        {/* Editorial Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#123D32]/40 border border-[#D6B66F]/30 text-xs text-[#D6B66F] mb-8 shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-[#D6B66F]" />
          <span className="tracking-wide">AI-Powered Synthetic User Research & Validation</span>
        </div>

        {/* Master Prompt Headline */}
        <h1 className="font-royal-title text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-[#F6F1E7] leading-[1.1] mb-6">
          Understand the people behind the <span className="gold-gradient-text">next great product.</span>
        </h1>

        {/* Master Prompt Supporting Copy */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-[#A8B0BC] leading-relaxed mb-10">
          Create synthetic customer personas, simulate research conversations, and uncover product opportunities before investing in a full-scale launch.
        </p>

        {/* Primary & Secondary CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => navigate('/dashboard')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-[#D6B66F] to-[#B3934B] text-[#0B0D10] text-sm font-bold tracking-wide hover:brightness-110 transition-all shadow-xl shadow-[#D6B66F]/20 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Launch Research Studio</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => navigate('/experiments')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#111827]/80 hover:bg-[#111827] border border-[#D6B66F]/30 text-sm font-semibold text-[#F6F1E7] hover:border-[#D6B66F]/60 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Compass className="w-4 h-4 text-[#D6B66F]" />
            <span>Explore a Demo Experiment</span>
          </button>
        </div>

        {/* Mandatory Transparency Disclaimer */}
        <div className="mt-12 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#111827]/60 border border-amber-500/20 text-xs text-amber-200/80">
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Notice: Findings are AI-generated synthetic simulations, not verified empirical customer research.</span>
        </div>
      </section>

      {/* Featured Subject Showcase: SwiftBite / Kadappa Cafe */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 py-16">
        <div className="p-8 rounded-2xl bg-gradient-to-b from-[#111827] to-[#0B0D10] border border-[#D6B66F]/20 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#123D32]/20 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8 mb-8 border-b border-[#D6B66F]/15 pb-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded bg-[#123D32] text-[#34D399] border border-[#1B5E4B]">
                  Featured Test Product
                </span>
                <span className="text-xs text-[#A8B0BC]">Metro India Working Professionals</span>
              </div>
              <h2 className="font-royal-title text-2xl sm:text-3xl font-bold text-[#F6F1E7]">
                SwiftBite — Smart Food Delivery App
              </h2>
            </div>
            <button
              onClick={() => navigate('/cafe')}
              className="px-4 py-2 rounded-lg bg-[#123D32]/50 hover:bg-[#123D32] border border-[#1B5E4B] text-xs font-semibold text-[#34D399] flex items-center gap-2 transition-all cursor-pointer"
            >
              <span>View Subject Prototype</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 5 Features Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { num: '01', title: '30-Min Delivery', desc: 'Predictable speed for sprint meetings' },
              { num: '02', title: 'Healthy Food Section', desc: 'Dietician-audited macros & clean oil' },
              { num: '03', title: 'Subscription Plan', desc: 'Monthly membership with zero fee' },
              { num: '04', title: 'Live Order Tracking', desc: 'Sub-meter map without phone calls' },
              { num: '05', title: '₹99 Delivery Fee', desc: 'Examining user price elasticity' },
            ].map((f, i) => (
              <div key={i} className="p-4 rounded-xl bg-[#0B0D10]/80 border border-[#D6B66F]/10 hover:border-[#D6B66F]/30 transition-all">
                <span className="text-xs font-mono font-bold text-[#D6B66F] block mb-1">{f.num}</span>
                <h3 className="text-sm font-semibold text-[#F6F1E7] mb-1">{f.title}</h3>
                <p className="text-xs text-[#A8B0BC] leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Research Workflow Section */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 py-16">
        <div className="text-center mb-14">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#D6B66F]">Scientific Rigor</span>
          <h2 className="font-royal-title text-3xl sm:text-4xl font-bold text-[#F6F1E7] mt-2">
            The Synthetic Research Intelligence Lifecycle
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-[#111827]/80 border border-[#D6B66F]/20 relative">
            <div className="w-12 h-12 rounded-xl bg-[#123D32]/50 border border-[#1B5E4B] flex items-center justify-center text-[#D6B66F] mb-4">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="font-royal-title text-lg font-bold text-[#F6F1E7] mb-2">1. Synthesize Diverse Personas</h3>
            <p className="text-xs text-[#A8B0BC] leading-relaxed">
              Generate distinct archetypes with specific budget limits, daily schedules, dietary preferences, and psychological objections.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#111827]/80 border border-[#D6B66F]/20 relative">
            <div className="w-12 h-12 rounded-xl bg-[#123D32]/50 border border-[#1B5E4B] flex items-center justify-center text-[#D6B66F] mb-4">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="font-royal-title text-lg font-bold text-[#F6F1E7] mb-2">2. Simulate Surveys & Interviews</h3>
            <p className="text-xs text-[#A8B0BC] leading-relaxed">
              Run parallel quantitative surveys and conduct stateful 1-on-1 discovery interviews powered by episodic vector memory.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#111827]/80 border border-[#D6B66F]/20 relative">
            <div className="w-12 h-12 rounded-xl bg-[#123D32]/50 border border-[#1B5E4B] flex items-center justify-center text-[#D6B66F] mb-4">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="font-royal-title text-lg font-bold text-[#F6F1E7] mb-2">3. Extract Evidence & PDF Reports</h3>
            <p className="text-xs text-[#A8B0BC] leading-relaxed">
              Cluster themes with genuine participant quotes, calculate 0–100 adoption scores, and download an executive editorial dossier.
            </p>
          </div>
        </div>
      </section>

      {/* Royal Footer */}
      <footer className="relative z-10 border-t border-[#D6B66F]/15 py-10 text-center text-xs text-[#A8B0BC]">
        <p className="font-royal-title tracking-wider text-[#F6F1E7]">
          REGALUX AI — SYNTHETIC USER RESEARCH INTELLIGENCE
        </p>
        <p className="mt-2 text-[11px] text-[#A8B0BC]/70 max-w-xl mx-auto">
          Built for executive product teams, UX strategists, and venture architects. All personas and conversations are synthetic simulations.
        </p>
      </footer>
    </div>
  );
};

export default LandingPage;
