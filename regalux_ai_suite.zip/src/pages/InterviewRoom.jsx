import React, { useState, useEffect, useRef } from 'react';
import { 
  MessagesSquare, Send, Sparkles, User, BrainCircuit, 
  Download, Clock, DollarSign, HeartPulse, ShieldAlert,
  HelpCircle, ChevronRight, RefreshCw, Layers
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

const SUGGESTED_QUESTIONS = [
  "How does an unexpected 20-minute delivery delay affect your working schedule?",
  "Would a ₹99 delivery fee prevent you from ordering a ₹200 lunch?",
  "What specific macro counts or certifications do you look for in healthy food?",
  "Under what circumstances would you subscribe to a ₹199 monthly delivery pass?",
  "What frustrates you most about existing food delivery applications?"
];

const InterviewRoom = () => {
  const { activeExperiment } = useAuth();
  const [personas, setPersonas] = useState([]);
  const [selectedPersonaId, setSelectedPersonaId] = useState("");
  const [session, setSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef(null);

  const selectedPersona = personas.find(p => p.id === selectedPersonaId) || personas[0];

  useEffect(() => {
    const init = async () => {
      try {
        setLoading(true);
        const pers = await api.getPersonas();
        setPersonas(pers);
        if (pers.length > 0) {
          const urlParams = new URLSearchParams(window.location.search);
          const reqId = urlParams.get('personaId');
          const targetP = (reqId && pers.find(p => p.id === reqId)) ? pers.find(p => p.id === reqId) : pers[0];
          setSelectedPersonaId(targetP.id);
          // Check for existing interview or start new
          const sessions = await api.getInterviews();
          const existing = sessions.find(s => s.persona_id === targetP.id);
          if (existing) {
            setSession(existing);
            setMessages(existing.messages || []);
          } else if (activeExperiment) {
            const newSession = await api.startInterview(targetP.id, {
              experiment_id: activeExperiment.id,
              persona_id: targetP.id,
              title: `Discovery Deep-Dive: ${targetP.name}`
            });
            setSession(newSession);
            setMessages(newSession.messages || []);
          }
        }
      } catch (e) {
        console.error("Interview init error:", e);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [activeExperiment]);

  const handleSelectPersona = async (pId) => {
    setSelectedPersonaId(pId);
    setLoading(true);
    try {
      const sessions = await api.getInterviews();
      const existing = sessions.find(s => s.persona_id === pId);
      if (existing) {
        setSession(existing);
        setMessages(existing.messages || []);
      } else if (activeExperiment) {
        const pObj = personas.find(p => p.id === pId);
        const newSession = await api.startInterview(pId, {
          experiment_id: activeExperiment.id,
          persona_id: pId,
          title: `Discovery Deep-Dive: ${pObj?.name || 'Persona'}`
        });
        setSession(newSession);
        setMessages(newSession.messages || []);
      }
    } catch (e) {
      console.error("Switch persona error:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (textToSend) => {
    const text = textToSend || inputText;
    if (!text.trim() || !session || sending) return;

    // Optimistically append researcher message
    const tempMsg = {
      id: `temp-${Date.now()}`,
      sender: 'researcher',
      content: text,
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, tempMsg]);
    setInputText("");
    setSending(true);

    try {
      const reply = await api.sendMessage(session.id, text);
      setMessages(prev => [...prev.filter(m => m.id !== tempMsg.id), tempMsg, reply]);
    } catch (e) {
      alert("Failed to send message: " + e.message);
    } finally {
      setSending(false);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  const handleExportTranscript = () => {
    if (!messages.length) return;
    const transcriptText = messages.map(m => {
      const role = m.sender === 'researcher' ? 'RESEARCHER' : (selectedPersona?.name || 'PERSONA');
      return `[${new Date(m.timestamp || Date.now()).toLocaleTimeString()}] ${role}:\n${m.content}\n${m.reasoning ? `[Internal Persona Reasoning: ${m.reasoning}]\n` : ''}\n`;
    }).join('\n----------------------------------------\n\n');

    const blob = new Blob([transcriptText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `regalux_transcript_${selectedPersona?.name.replace(/\s+/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-[calc(100vh-8.5rem)] flex flex-col space-y-4 max-w-7xl mx-auto">
      {/* Top Header & Persona Selector Bar */}
      <div className="flex items-center justify-between border-b border-[#D6B66F]/15 pb-4 shrink-0">
        <div className="flex items-center gap-3">
          <MessagesSquare className="w-5 h-5 text-[#D6B66F]" />
          <div>
            <h1 className="font-royal-title text-xl font-bold text-[#F6F1E7]">
              Interview Room — Stateful Persona Simulation
            </h1>
            <p className="text-[11px] text-[#A8B0BC]">
              Conduct real-time qualitative discovery conversations with multi-turn episodic memory.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Persona Picker */}
          <select
            value={selectedPersonaId}
            onChange={(e) => handleSelectPersona(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-[#111827] border border-[#D6B66F]/30 text-xs text-[#F6F1E7] focus:outline-none focus:border-[#D6B66F]"
          >
            {personas.map(p => (
              <option key={p.id} value={p.id} className="bg-[#111827]">
                {p.name} ({p.occupation})
              </option>
            ))}
          </select>

          <button
            onClick={handleExportTranscript}
            className="px-3 py-1.5 rounded-lg bg-[#111827] border border-[#D6B66F]/30 hover:border-[#D6B66F] text-xs font-semibold text-[#F6F1E7] flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#D6B66F]" />
            <span className="hidden sm:inline">Export Transcript</span>
          </button>
        </div>
      </div>

      {/* 3-Pane Split Layout */}
      <div className="flex-1 grid grid-cols-12 gap-4 min-h-0">
        {/* Left Pane: Persona Dossier (3 cols) */}
        <div className="col-span-12 lg:col-span-3 royal-card rounded-2xl border border-[#D6B66F]/20 p-5 overflow-y-auto space-y-4">
          <div className="text-center pb-4 border-b border-[#D6B66F]/15">
            <img
              src={selectedPersona?.avatar}
              alt={selectedPersona?.name}
              className="w-20 h-20 rounded-2xl object-cover mx-auto mb-3 border-2 border-[#D6B66F]/40 shadow-xl"
            />
            <h2 className="font-royal-title text-base font-bold text-[#F6F1E7]">{selectedPersona?.name}</h2>
            <p className="text-xs text-[#D6B66F] font-medium">{selectedPersona?.occupation}, {selectedPersona?.age || 30}</p>
            <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full text-[9px] font-semibold bg-[#123D32] text-[#34D399] border border-[#1B5E4B]">
              {selectedPersona?.segment}
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Schedule & Routine</span>
              <p className="text-[#F6F1E7]/90 mt-0.5 leading-relaxed">{selectedPersona?.schedule}</p>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Budget Sensitivity</span>
              <p className="text-[#F6F1E7]/90 mt-0.5 leading-relaxed">{selectedPersona?.budget}</p>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-[#A8B0BC]">Dietary Preferences</span>
              <p className="text-[#F6F1E7]/90 mt-0.5 leading-relaxed">{selectedPersona?.dietary_prefs}</p>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-rose-400">Primary Objections</span>
              <ul className="list-disc list-inside space-y-1 text-[#F6F1E7]/90 text-[11px] mt-0.5">
                {selectedPersona?.objections?.map((obj, i) => <li key={i}>{obj}</li>)}
              </ul>
            </div>
          </div>
        </div>

        {/* Center Pane: Conversational Chat (6 cols) */}
        <div className="col-span-12 lg:col-span-6 royal-card rounded-2xl border border-[#D6B66F]/20 flex flex-col min-h-0 overflow-hidden">
          {/* Chat Messages Log */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {messages.map((m, idx) => {
              const isResearcher = m.sender === 'researcher';
              return (
                <div key={idx} className={`flex flex-col ${isResearcher ? 'items-end' : 'items-start'}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold text-[#A8B0BC]">
                      {isResearcher ? 'You (Principal Researcher)' : selectedPersona?.name}
                    </span>
                    <span className="text-[9px] text-[#A8B0BC]/60">
                      {new Date(m.timestamp || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                    isResearcher
                      ? 'bg-gradient-to-r from-[#123D32] to-[#111827] text-[#F6F1E7] border border-[#1B5E4B] rounded-br-none shadow-md'
                      : 'bg-[#111827] text-[#F6F1E7] border border-[#D6B66F]/25 rounded-bl-none shadow-md'
                  }`}>
                    <p>{m.content}</p>

                    {!isResearcher && m.reasoning && (
                      <div className="mt-2 pt-2 border-t border-[#D6B66F]/15 text-[10px] text-[#D6B66F] italic">
                        💭 Persona Reflection: {m.reasoning}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {sending && (
              <div className="flex items-center gap-2 text-xs text-[#D6B66F] p-3 rounded-xl bg-[#111827]/70 border border-[#D6B66F]/20 animate-pulse">
                <BrainCircuit className="w-4 h-4 animate-spin text-[#D6B66F]" />
                <span>{selectedPersona?.name} is reflecting and consulting episodic memory...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Opening Questions Pill Bar */}
          <div className="px-4 py-2 bg-[#0B0D10]/80 border-t border-[#D6B66F]/10 flex items-center gap-2 overflow-x-auto text-[10px]">
            <span className="text-[#A8B0BC] uppercase tracking-wider shrink-0 font-semibold">Suggested:</span>
            {SUGGESTED_QUESTIONS.map((sq, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(sq)}
                className="px-2.5 py-1 rounded-full bg-[#111827] border border-[#D6B66F]/20 text-[#D6B66F] hover:bg-[#123D32] whitespace-nowrap transition-colors cursor-pointer"
              >
                {sq}
              </button>
            ))}
          </div>

          {/* Message Input Box */}
          <div className="p-4 bg-[#0B0D10] border-t border-[#D6B66F]/15 flex items-center gap-3">
            <input
              type="text"
              placeholder={`Ask ${selectedPersona?.name || 'the persona'} a question about SwiftBite...`}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#111827] border border-[#D6B66F]/25 text-xs text-[#F6F1E7] placeholder-[#A8B0BC]/40 focus:outline-none focus:border-[#D6B66F]"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim() || sending}
              className="p-2.5 rounded-xl bg-[#D6B66F] text-[#0B0D10] font-bold hover:brightness-110 disabled:opacity-40 transition-all cursor-pointer shadow-md shadow-[#D6B66F]/15"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Pane: Memory Radar & Live Insights (3 cols) */}
        <div className="col-span-12 lg:col-span-3 royal-card rounded-2xl border border-[#D6B66F]/20 p-5 overflow-y-auto space-y-4">
          <div className="border-b border-[#D6B66F]/15 pb-3">
            <div className="flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-[#D6B66F]" />
              <h3 className="font-royal-title text-sm font-bold text-[#F6F1E7]">Vector Memory Radar</h3>
            </div>
            <p className="text-[10px] text-[#A8B0BC] mt-0.5">
              Episodic facts retrieved from prior turns via semantic cosine matching.
            </p>
          </div>

          {/* Memory Items */}
          <div className="space-y-2.5">
            {[
              { type: 'Budget Rule', text: '₹99 fee causes cart abandonment unless monthly membership waives fee.' },
              { type: 'Work SLA', text: '30-minute arrival window is essential between sprint standups.' },
              { type: 'Dietary Priority', text: 'Demands transparent protein & macro certifications on clean bowls.' },
            ].map((mem, i) => (
              <div key={i} className="p-3 rounded-xl bg-[#0B0D10] border border-[#D6B66F]/15 space-y-1">
                <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-[#123D32] text-[#34D399]">
                  {mem.type}
                </span>
                <p className="text-xs text-[#A8B0BC] leading-relaxed pt-1">{mem.text}</p>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-[#D6B66F]/15">
            <span className="text-[10px] uppercase font-bold text-[#D6B66F] tracking-wider block mb-2">
              Persona Voice Consistency
            </span>
            <div className="p-3 rounded-xl bg-[#123D32]/30 border border-[#1B5E4B] text-xs space-y-1">
              <p className="font-semibold text-emerald-300">Identity Guard Active</p>
              <p className="text-[11px] text-[#A8B0BC]">
                Zero cross-persona hallucination. Tone calibrated to {selectedPersona?.occupation}.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewRoom;
